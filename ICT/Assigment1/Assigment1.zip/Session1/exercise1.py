# Ask for your name and surname and save it in different variables

name = input("Enter your name: ")
surname = input("Enter your surname: ")

print("Hi " + name + " " + surname + " and welcome to ICT !")